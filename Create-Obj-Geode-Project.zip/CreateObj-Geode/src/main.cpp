#include <Geode/Geode.hpp>
#include <Geode/modify/EditorUI.hpp>

using namespace geode::prelude;

namespace create_obj {
enum class Collision { Solid, None, Hazard };
enum class Shape { None, Square, Slope, Circle, Triangle };
struct ObjectDef {
    std::string name;
    std::string icon;
    std::string placed;
    Collision collision = Collision::None;
    Shape shape = Shape::None;
    float x = 1.f;
    float y = 1.f;
};
static std::vector<ObjectDef> objects;
}

class $modify(CreateObjEditorUI, EditorUI) {
    bool init(LevelEditorLayer* editorLayer) {
        if (!EditorUI::init(editorLayer)) return false;
        log::info("Create Obj editor hook loaded");
        return true;
    }
};

$on_mod(Loaded) {
    log::info("Create Obj v0.1.0 loaded");
}
