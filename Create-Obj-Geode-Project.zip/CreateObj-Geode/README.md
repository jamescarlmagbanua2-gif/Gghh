# Create Obj

Geode Android project for the Create Obj editor-object system.

IMPORTANT: This is a compile-ready editor-hook scaffold, not a claim that the complete custom-object engine is already implemented. The actual persistent custom object registration/rendering/collision system requires the exact Geometry Dash 2.2081 bindings and testing. It is safer than pretending an untested implementation will work.

The intended UI is:
- + Create Object
- Object name
- Icon PNG
- Placed PNG
- Solid / No Collision / Hazard
- Solid: Square / Slope
- Hazard: Circle / Triangle / Square
- No Collision: no shape or hitbox
- X/Y hitbox size
- Create and delete

The workflow builds Android32 and Android64 automatically on GitHub Actions using Geode's official build action.
